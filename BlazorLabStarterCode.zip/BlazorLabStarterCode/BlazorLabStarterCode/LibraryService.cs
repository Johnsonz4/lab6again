﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Blazor_Lab_Starter_Code
{
    public class LibraryService
    {
        private List<Book> books = new List<Book>();
        private List<User> users = new List<User>();
        private Dictionary<User, List<Book>> borrowedBooks = new Dictionary<User, List<Book>>();

        public LibraryService()
        {
            InitializeSampleData();
        }

        private void InitializeSampleData()
        {
      
            books.Add(new Book { Id = 1, Title = "Book1", Author = "Author1", ISBN = "ISBN1" });
            books.Add(new Book { Id = 2, Title = "Book2", Author = "Author2", ISBN = "ISBN2" });
            books.Add(new Book { Id = 3, Title = "Book3", Author = "Author3", ISBN = "ISBN3" });

            
            users.Add(new User { Id = 1, Name = "User1", Email = "user1@example.com" });
            users.Add(new User { Id = 2, Name = "User2", Email = "user2@example.com" });
        }

        public List<Book> GetBooks()
        {
            return books.ToList();
        }

        public List<User> GetUsers()
        {
            return users.ToList();
        }

        public Dictionary<User, List<Book>> GetBorrowedBooks()
        {
            return borrowedBooks.ToDictionary(entry => entry.Key, entry => entry.Value.ToList());
        }

        public void BorrowBook(int bookId, int userId)
        {
            Book bookToBorrow = books.FirstOrDefault(b => b.Id == bookId);
            User userBorrowing = users.FirstOrDefault(u => u.Id == userId);

            if (bookToBorrow != null && userBorrowing != null)
            {
                if (!borrowedBooks.ContainsKey(userBorrowing))
                {
                    borrowedBooks[userBorrowing] = new List<Book>();
                }

                borrowedBooks[userBorrowing].Add(bookToBorrow);
                books.Remove(bookToBorrow);
            }
        }

        public void ReturnBook(int userId, int bookIndex)
        {
            User userReturning = users.FirstOrDefault(u => u.Id == userId);

            if (userReturning != null && borrowedBooks.ContainsKey(userReturning) && borrowedBooks[userReturning].Count > bookIndex)
            {
                Book bookToReturn = borrowedBooks[userReturning][bookIndex];
                borrowedBooks[userReturning].RemoveAt(bookIndex);
                books.Add(bookToReturn);
            }
        }
    }
}
